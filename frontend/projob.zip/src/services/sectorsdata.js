export const sectors = [
  {
    Sector : "Plomberie",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Menuiserie",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Électricité",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Jardinage",
    Description : "",
    id:4,
    icone: "icone.png"
  
  },
  {
    Sector : "Maçonnerie",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Peinture",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Décoration",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Nettoyage",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Électroménager",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Maintenance Mécanique",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Froid",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Métallurgie",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Forage",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Maintenance électronique",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Engins ",
    Description : "",
    id:4,
    icone: "icone.png"
  },
  {
    Sector : "Transport",
    Description : "",
    id:4,
    icone: "icone.png"
  },
]
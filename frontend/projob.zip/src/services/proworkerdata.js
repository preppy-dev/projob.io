export const proworker = [
  { 
    id:1,
    FullName:"Ousmane Diarra",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:2,
    FullName:"Lacina traoré",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:3,
    FullName:"Moussa sogodogo",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:4,
    FullName:"Fousseni mbodj",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Demba Diallo",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:5,
    FullName:"kadia Cisse ",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:6,
    FullName:"Aboubacar KANOUTE",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"VERTA-PRO SARL",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:7,
    FullName:"Papou",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:8,
    FullName:"Boura",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Youssouf Keita",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Moussa Bah",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Ladji",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:9,
    FullName:"Papou",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:10,
    FullName:"Sakir Diakite",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:11,
    FullName:"leh Coulibaly ",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Moussa Diarra",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Fousseini ",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Binta Décor",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Cisse Électronique",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
  { 
    id:1,
    FullName:"Geoffroy Coulibaly",
    Number:"92310618",
    Email:"O.diarraz791@gmail.com",
    Ville:"Bamako",
    Commune:"1",
    Quartier:"Hamdalaye Aci",
    Sectors:[
      "Transport",
      "Maintenance Mécanique",
    ],
    OderSectors:[
      "Engins"  
    ],
    status:"Professionnel",
    disponibility:"temporaire",
    Image:"photo.jpeg"
  },
]
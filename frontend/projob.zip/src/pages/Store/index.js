import React from 'react'
import './style.css'

const Store = () =>{
  return(
    <div className="store">
     La boutique Artisanal...
    </div>
  )
}

export default Store;
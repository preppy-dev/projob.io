import React from 'react'
import './style.css'

const SectorSingle = () =>{
  return(
    <div className="SectorSingle">
    Sector Single
    </div>
  )
}

export default SectorSingle;
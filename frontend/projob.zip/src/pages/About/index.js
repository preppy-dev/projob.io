import React from 'react'
import './style.css'

const About = () =>{
  return(
    <div className="about-us">
     <div className="about">
       <h1>Qui sommes nous</h1>
       <p>
          ProJob se veut être le crossing qui met en relation les
          acteurs des services professionnels en offrant des 
          services de qualités diversifiés sur une plateforme
          facile d’accès. Notre plateforme a pour but de
          permettre à chacun de jouir de la sécurité d'emploi,
           d'un environnement de travail sûr et de possibilités 
           de croissance professionnelle à travers une visibilité 
           accrue des produits et services. De plus, pour un ménage, 
           engager quelqu'un pour un travail devrait être sûr, pratique et juste. 
           Notre plate-forme est conçue pour répondre à chacun de ces problèmes, 
           offrant un réseau de professionnels qui grandit et s’améliore avec le temps. 
           Pour les entreprises
            et les institutions, Projob vous offre toute une gamme de services : mise 
            à disposition des professionnels techniques, renforcement de capacités des techniciens…
       </p>
     </div>
     <div className="OBJECTIFs">

     </div>
    </div>
  )
}

export default About;
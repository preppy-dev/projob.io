import React from 'react'
import './style.css'

const Contact = () =>{
  return(
    <div className="contact">
    Contactez-nous
    </div>
  )
}

export default Contact;